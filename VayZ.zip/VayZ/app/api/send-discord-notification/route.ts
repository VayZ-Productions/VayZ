import { NextResponse } from "next/server"

// Your webhook URL for sending notifications
const DISCORD_WEBHOOK_URL =
  "https://discord.com/api/webhooks/1376176389333713038/Bqf0nU5DBHvBjVJti4AJQ4iTAxGo2dQiyior_Z001hoNsCYzqWvu9QgtpdTIiABwX7PU"

export async function POST(request: Request) {
  try {
    const { message, username, avatarUrl } = await request.json()

    const webhookPayload = {
      content: message,
      username: username || "VayZ System",
      avatar_url: avatarUrl || undefined,
      embeds: [
        {
          title: "🔥 VayZ System Alert",
          description: message,
          color: 0xef4444, // Red color
          timestamp: new Date().toISOString(),
          footer: {
            text: "VayZ Gaming System",
          },
        },
      ],
    }

    const response = await fetch(DISCORD_WEBHOOK_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(webhookPayload),
    })

    if (!response.ok) {
      throw new Error(`Discord webhook failed: ${response.status}`)
    }

    return NextResponse.json({ success: true, message: "Notification sent to Discord" })
  } catch (error) {
    console.error("Discord notification error:", error)
    return NextResponse.json({ error: "Failed to send Discord notification" }, { status: 500 })
  }
}
