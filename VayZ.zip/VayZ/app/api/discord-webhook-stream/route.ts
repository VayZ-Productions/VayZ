import type { NextRequest } from "next/server"
import { updateWebhookActivity } from "../webhook-status/route"

// Store for real-time data
let currentDiscordData = {
  memberCount: 71,
  onlineCount: 23,
  serverName: "VayZ",
  lastUpdated: new Date(),
}

// Store active connections
const connections = new Set<ReadableStreamDefaultController>()

export async function GET(request: NextRequest) {
  // Update webhook activity when stream is requested
  updateWebhookActivity()

  const stream = new ReadableStream({
    start(controller) {
      // Add this connection to our set
      connections.add(controller)

      // Send initial data
      controller.enqueue(`data: ${JSON.stringify(currentDiscordData)}\n\n`)

      // Keep connection alive with heartbeat
      const heartbeat = setInterval(() => {
        try {
          updateWebhookActivity() // Update activity on each heartbeat
          controller.enqueue(`data: ${JSON.stringify({ type: "heartbeat", timestamp: Date.now() })}\n\n`)
        } catch (error) {
          clearInterval(heartbeat)
          connections.delete(controller)
        }
      }, 30000)

      // Cleanup on close
      request.signal.addEventListener("abort", () => {
        clearInterval(heartbeat)
        connections.delete(controller)
        try {
          controller.close()
        } catch (error) {
          // Connection already closed
        }
      })
    },
  })

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET",
      "Access-Control-Allow-Headers": "Content-Type",
    },
  })
}

// Function to broadcast updates to all connected clients
export function broadcastUpdate(data: any) {
  updateWebhookActivity() // Update activity when data is broadcast

  currentDiscordData = { ...currentDiscordData, ...data, lastUpdated: new Date() }

  connections.forEach((controller) => {
    try {
      controller.enqueue(`data: ${JSON.stringify(currentDiscordData)}\n\n`)
    } catch (error) {
      // Remove dead connections
      connections.delete(controller)
    }
  })
}
