import { NextResponse } from "next/server"

// Helper endpoint to find the correct Guild ID from your bot
export async function GET() {
  try {
    const DISCORD_BOT_TOKEN = process.env.DISCORD_BOT_TOKEN

    if (!DISCORD_BOT_TOKEN) {
      return NextResponse.json({ error: "Bot token not configured" }, { status: 400 })
    }

    const authHeader = DISCORD_BOT_TOKEN.startsWith("Bot ") ? DISCORD_BOT_TOKEN : `Bot ${DISCORD_BOT_TOKEN}`

    // Get all guilds the bot is in
    const guildsResponse = await fetch("https://discord.com/api/v10/users/@me/guilds", {
      headers: {
        Authorization: authHeader,
        "Content-Type": "application/json",
      },
    })

    if (!guildsResponse.ok) {
      const errorText = await guildsResponse.text()
      return NextResponse.json(
        { error: `Discord API error: ${guildsResponse.status} - ${errorText}` },
        { status: guildsResponse.status },
      )
    }

    const guilds = await guildsResponse.json()

    return NextResponse.json({
      success: true,
      guilds: guilds.map((guild: any) => ({
        id: guild.id,
        name: guild.name,
        icon: guild.icon,
        owner: guild.owner,
        permissions: guild.permissions,
      })),
      message: `Found ${guilds.length} guild(s). Use one of these IDs in your DISCORD_GUILD_ID environment variable.`,
    })
  } catch (error) {
    console.error("Guild finder error:", error)
    return NextResponse.json({ error: "Failed to fetch guilds" }, { status: 500 })
  }
}
