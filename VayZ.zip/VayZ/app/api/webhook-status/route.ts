import { NextResponse } from "next/server"

// Store the last webhook activity timestamp
let lastWebhookActivity = Date.now()
const WEBHOOK_TIMEOUT = 60000 // 1 minute

// Update this function when webhook is active
export function updateWebhookActivity() {
  lastWebhookActivity = Date.now()
}

export async function GET() {
  const now = Date.now()
  const timeSinceLastActivity = now - lastWebhookActivity
  const active = timeSinceLastActivity < WEBHOOK_TIMEOUT

  return NextResponse.json({
    active,
    lastActivity: new Date(lastWebhookActivity).toISOString(),
    timeSinceLastActivity,
  })
}
