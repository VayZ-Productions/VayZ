import { NextResponse } from "next/server"

// Store bot status in memory (in production, use a database)
let botStatus = {
  online: false,
  token: null as string | null,
  guilds: 0,
  users: 0,
  lastActivity: new Date(),
  connectedGuilds: [] as any[],
}

export async function POST(request: Request) {
  try {
    const { action, token } = await request.json()

    if (action === "start") {
      if (!token) {
        return NextResponse.json({ error: "Bot token required" }, { status: 400 })
      }

      // Test the bot token by getting bot info
      const authHeader = token.startsWith("Bot ") ? token : `Bot ${token}`

      try {
        // Get bot user info
        const botResponse = await fetch("https://discord.com/api/v10/users/@me", {
          headers: {
            Authorization: authHeader,
            "Content-Type": "application/json",
          },
        })

        if (!botResponse.ok) {
          const errorText = await botResponse.text()
          return NextResponse.json(
            { error: `Invalid bot token: ${botResponse.status} - ${errorText}` },
            { status: 400 },
          )
        }

        const botUser = await botResponse.json()

        // Get guilds the bot is in
        const guildsResponse = await fetch("https://discord.com/api/v10/users/@me/guilds", {
          headers: {
            Authorization: authHeader,
            "Content-Type": "application/json",
          },
        })

        let guilds = []
        if (guildsResponse.ok) {
          guilds = await guildsResponse.json()
        }

        // Update bot status
        botStatus = {
          online: true,
          token,
          guilds: guilds.length,
          users: guilds.reduce((total: number, guild: any) => total + (guild.approximate_member_count || 0), 0),
          lastActivity: new Date(),
          connectedGuilds: guilds,
        }

        console.log(`Discord bot started: ${botUser.username}#${botUser.discriminator}`)
        console.log(`Connected to ${guilds.length} guild(s)`)

        return NextResponse.json({
          success: true,
          message: `Discord bot started successfully as ${botUser.username}`,
          status: botStatus,
          botInfo: {
            username: botUser.username,
            discriminator: botUser.discriminator,
            id: botUser.id,
            avatar: botUser.avatar,
          },
        })
      } catch (error) {
        console.error("Bot token validation error:", error)
        return NextResponse.json({ error: "Failed to validate bot token" }, { status: 400 })
      }
    } else if (action === "stop") {
      // Stop the bot
      botStatus.online = false
      botStatus.token = null
      botStatus.connectedGuilds = []

      console.log("Discord bot stopped")

      return NextResponse.json({
        success: true,
        message: "Discord bot stopped successfully",
        status: botStatus,
      })
    }

    return NextResponse.json({ error: "Invalid action" }, { status: 400 })
  } catch (error) {
    console.error("Bot control error:", error)
    return NextResponse.json({ error: "Failed to control bot" }, { status: 500 })
  }
}

export async function GET() {
  return NextResponse.json({
    status: botStatus,
    uptime: botStatus.online ? Date.now() - botStatus.lastActivity.getTime() : 0,
  })
}
