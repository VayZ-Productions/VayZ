import { NextResponse } from "next/server"

// Store analytics data in memory (in production, use a database)
const analyticsData = {
  totalVisitors: 1247,
  activationsToday: 23,
  activationsThisWeek: 156,
  activationsThisMonth: 678,
  discordNotifications: 156,
  topCountries: [
    { country: "United States", visitors: 423 },
    { country: "United Kingdom", visitors: 234 },
    { country: "Germany", visitors: 189 },
    { country: "Canada", visitors: 156 },
    { country: "Australia", visitors: 134 },
  ],
  hourlyStats: Array.from({ length: 24 }, (_, i) => ({
    hour: i,
    visitors: Math.floor(Math.random() * 50) + 10,
    activations: Math.floor(Math.random() * 10),
  })),
  lastUpdated: new Date(),
}

export async function GET() {
  // Simulate real-time data updates
  analyticsData.totalVisitors += Math.floor(Math.random() * 3)
  analyticsData.lastUpdated = new Date()

  return NextResponse.json({
    analytics: analyticsData,
  })
}

export async function POST(request: Request) {
  try {
    const { event, data } = await request.json()

    // Track different events
    switch (event) {
      case "activation":
        analyticsData.activationsToday += 1
        analyticsData.activationsThisWeek += 1
        analyticsData.activationsThisMonth += 1
        break
      case "visitor":
        analyticsData.totalVisitors += 1
        break
      case "notification":
        analyticsData.discordNotifications += 1
        break
    }

    analyticsData.lastUpdated = new Date()

    return NextResponse.json({
      success: true,
      analytics: analyticsData,
    })
  } catch (error) {
    console.error("Analytics tracking error:", error)
    return NextResponse.json({ error: "Failed to track event" }, { status: 500 })
  }
}
