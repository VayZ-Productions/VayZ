import { NextResponse } from "next/server"
import { broadcastUpdate } from "../discord-webhook-stream/route"
import { updateWebhookActivity } from "../webhook-status/route"

const DISCORD_BOT_TOKEN = process.env.DISCORD_BOT_TOKEN
const DISCORD_GUILD_ID = process.env.DISCORD_GUILD_ID
const WEBHOOK_SECRET = process.env.DISCORD_WEBHOOK_SECRET || "your-secret-key"

export async function POST(request: Request) {
  try {
    // Update webhook activity timestamp
    updateWebhookActivity()

    const body = await request.json()

    // Verify webhook secret (optional but recommended)
    const providedSecret = request.headers.get("x-webhook-secret")
    if (providedSecret !== WEBHOOK_SECRET) {
      console.log("Invalid webhook secret")
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    console.log("Discord webhook received:", body)

    // Handle different Discord events
    if (body.type === "GUILD_MEMBER_ADD" || body.type === "GUILD_MEMBER_REMOVE") {
      // Fetch updated member count when someone joins/leaves
      await fetchAndBroadcastDiscordData()
    } else if (body.type === "PRESENCE_UPDATE") {
      // Handle online status changes
      await fetchAndBroadcastDiscordData()
    } else if (body.type === "MANUAL_UPDATE") {
      // Manual trigger for updates
      await fetchAndBroadcastDiscordData()
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Webhook error:", error)
    return NextResponse.json({ error: "Webhook processing failed" }, { status: 500 })
  }
}

// Function to fetch Discord data and broadcast to all clients
async function fetchAndBroadcastDiscordData() {
  try {
    if (!DISCORD_BOT_TOKEN || !DISCORD_GUILD_ID) {
      return
    }

    const authHeader = DISCORD_BOT_TOKEN.startsWith("Bot ") ? DISCORD_BOT_TOKEN : `Bot ${DISCORD_BOT_TOKEN}`

    // Fetch guild data
    const guildResponse = await fetch(`https://discord.com/api/v10/guilds/${DISCORD_GUILD_ID}?with_counts=true`, {
      headers: {
        Authorization: authHeader,
        "Content-Type": "application/json",
      },
    })

    if (guildResponse.ok) {
      const guildData = await guildResponse.json()

      // Try to get online count
      let onlineCount = Math.floor((guildData.approximate_member_count || 71) * 0.3)

      try {
        const previewResponse = await fetch(`https://discord.com/api/v10/guilds/${DISCORD_GUILD_ID}/preview`, {
          headers: {
            Authorization: authHeader,
            "Content-Type": "application/json",
          },
        })

        if (previewResponse.ok) {
          const previewData = await previewResponse.json()
          onlineCount = previewData.approximate_presence_count || onlineCount
        }
      } catch (error) {
        // Use estimate if preview fails
      }

      // Broadcast the update to all connected clients
      broadcastUpdate({
        memberCount: guildData.approximate_member_count || guildData.member_count || 71,
        onlineCount: onlineCount,
        serverName: guildData.name || "VayZ",
      })

      console.log("Discord data updated and broadcasted")
    }
  } catch (error) {
    console.error("Error fetching Discord data for webhook:", error)
  }
}

// Manual trigger endpoint
export async function GET() {
  updateWebhookActivity() // Update activity on manual trigger
  await fetchAndBroadcastDiscordData()
  return NextResponse.json({ success: true, message: "Manual update triggered" })
}
