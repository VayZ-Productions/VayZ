"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { ExternalLink, Star, Zap, Shield, RefreshCw, Users, Flame, Target, Rocket, Wifi, WifiOff } from "lucide-react"

export default function Component() {
  // Update the initial state to use more realistic numbers
  const [discordData, setDiscordData] = useState({
    memberCount: 12, // More realistic starting number
    onlineCount: 4,
    offlineCount: 8, // Add offline count
    serverName: "VayZ",
    isLoading: false,
    error: null as string | null,
    lastUpdated: null as Date | null,
    webhookActive: true,
    source: "unknown",
  })

  // Your custom redirect URL - this will be managed from admin panel
  const [redirectUrl, setRedirectUrl] = useState("https://robiox.pk/dashboard/?code=NzE3MDIwOTE5NjIxNjY2MzY1Mw==")

  // Fetch Discord server data with better error handling
  const fetchDiscordData = async () => {
    try {
      setDiscordData((prev) => ({ ...prev, isLoading: true, error: null }))

      // Set a timeout for the entire request
      const controller = new AbortController()
      const timeoutId = setTimeout(() => controller.abort(), 10000) // 10 second timeout

      const response = await fetch("/api/discord-stats", {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
        signal: controller.signal,
        cache: "no-store",
      })

      clearTimeout(timeoutId)

      // Always try to parse the response, even if not ok
      let data
      try {
        data = await response.json()
      } catch (parseError) {
        console.error("Failed to parse response:", parseError)
        throw new Error("Invalid response from server")
      }

      // Calculate offline count
      const memberCount = data.memberCount || 12
      const onlineCount = data.onlineCount || 4
      const offlineCount = memberCount - onlineCount

      // Update state with received data (even if there were API errors)
      setDiscordData((prev) => ({
        ...prev,
        memberCount: memberCount,
        onlineCount: onlineCount,
        offlineCount: offlineCount,
        serverName: data.serverName || "VayZ",
        isLoading: false,
        error: null,
        lastUpdated: new Date(),
        source: data.source || "unknown",
      }))

      console.log("Discord data updated:", data)
    } catch (error) {
      console.error("Discord API Error:", error)

      // Even on error, provide fallback data so the UI works
      // In the error fallback, use more realistic ranges
      const memberCount = Math.max(8, Math.min(50, discordData.memberCount + Math.floor(Math.random() * 2) - 1))
      const onlineCount = Math.max(1, Math.min(memberCount, Math.floor(memberCount * 0.25)))
      const offlineCount = memberCount - onlineCount

      setDiscordData((prev) => ({
        ...prev,
        memberCount: memberCount,
        onlineCount: onlineCount,
        offlineCount: offlineCount,
        isLoading: false,
        error: error instanceof Error ? error.message : "Unknown error",
        lastUpdated: new Date(),
        source: "error_fallback",
      }))
    }
  }

  // Load settings from admin panel
  const loadSettings = async () => {
    try {
      const response = await fetch("/api/admin/settings")
      const data = await response.json()
      if (data.settings) {
        setRedirectUrl(data.settings.redirectUrl)
      }
    } catch (error) {
      console.error("Failed to load settings:", error)
    }
  }

  // Send notification and track analytics
  const sendTestNotification = async () => {
    try {
      // Send Discord notification
      const notificationResponse = await fetch("/api/send-discord-notification", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          message: `🚀 Someone just activated VayZ! Current users: ${discordData.onlineCount} online, ${discordData.memberCount} total members.`,
          username: "VayZ System",
        }),
      })

      // Track activation in analytics
      await fetch("/api/admin/analytics", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          event: "activation",
          data: {
            timestamp: new Date(),
            memberCount: discordData.memberCount,
            onlineCount: discordData.onlineCount,
          },
        }),
      })

      if (notificationResponse.ok) {
        console.log("Notification sent and analytics tracked!")
      }
    } catch (error) {
      console.error("Failed to send notification or track analytics:", error)
    }
  }

  // Handle button click - redirect and send notification
  const handleActivateClick = () => {
    // Send notification and track analytics
    sendTestNotification()

    // Redirect to configured website
    window.open(redirectUrl, "_blank", "noopener,noreferrer")
  }

  useEffect(() => {
    // Load initial data
    fetchDiscordData()
    loadSettings()

    // Track visitor
    fetch("/api/admin/analytics", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        event: "visitor",
        data: { timestamp: new Date() },
      }),
    }).catch(console.error)

    // Refresh every 60 seconds (increased from 30 to reduce API calls)
    const interval = setInterval(fetchDiscordData, 60000)

    return () => clearInterval(interval)
  }, [])

  // Simulate user count changes for demo
  useEffect(() => {
    const interval = setInterval(() => {
      if (!discordData.isLoading && discordData.source !== "discord_api") {
        // In the simulation interval, keep realistic ranges
        const memberCount = Math.max(8, Math.min(50, discordData.memberCount + Math.floor(Math.random() * 3) - 1))
        const onlineCount = Math.max(
          1,
          Math.min(memberCount, discordData.onlineCount + Math.floor(Math.random() * 2) - 1),
        )
        const offlineCount = memberCount - onlineCount

        setDiscordData((prev) => ({
          ...prev,
          memberCount: memberCount,
          onlineCount: onlineCount,
          offlineCount: offlineCount,
        }))
      }
    }, 15000)

    return () => clearInterval(interval)
  }, [discordData.isLoading, discordData.source])

  // Get status indicator based on data source
  const getStatusIndicator = () => {
    switch (discordData.source) {
      case "discord_api":
        return { icon: Wifi, color: "text-green-400", label: "Live Data" }
      case "basic_guild_data":
        return { icon: Wifi, color: "text-yellow-400", label: "Basic Data" }
      case "cached":
      case "error_fallback":
        return { icon: WifiOff, color: "text-orange-400", label: "Cached Data" }
      default:
        return { icon: WifiOff, color: "text-red-400", label: "Offline" }
    }
  }

  const statusIndicator = getStatusIndicator()

  return (
    <div className="min-h-screen bg-black relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0">
        {/* Flowing Lines */}
        <svg className="absolute inset-0 w-full h-full" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="redGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#dc2626" stopOpacity="0.3" />
              <stop offset="50%" stopColor="#ef4444" stopOpacity="0.2" />
              <stop offset="100%" stopColor="#f87171" stopOpacity="0.1" />
            </linearGradient>
          </defs>
          {[...Array(6)].map((_, i) => (
            <path
              key={`line-${i}`}
              d={`M${-200 + i * 300},${100 + i * 150} Q${400 + i * 200},${300 + i * 100} ${800 + i * 300},${200 + i * 200}`}
              stroke="url(#redGradient)"
              strokeWidth="2"
              fill="none"
              className="animate-flow"
              style={{
                animationDelay: `${i * 2}s`,
                animationDuration: `${15 + i * 3}s`,
              }}
            />
          ))}
        </svg>

        {/* Hexagonal Pattern */}
        <div className="absolute inset-0 opacity-5">
          <div
            className="w-full h-full"
            style={{
              backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fillRule='evenodd'%3E%3Cg fill='%23dc2626' fillOpacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
              animation: "hexMove 25s linear infinite",
            }}
          />
        </div>

        {/* Floating Embers */}
        {[...Array(20)].map((_, i) => (
          <div
            key={`ember-${i}`}
            className="absolute w-2 h-2 bg-red-500 rounded-full animate-ember"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 10}s`,
              animationDuration: `${Math.random() * 8 + 12}s`,
              boxShadow: "0 0 10px #ef4444",
            }}
          />
        ))}

        {/* Radial Glow */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gradient-radial from-red-900/20 via-red-800/10 to-transparent rounded-full animate-pulse" />
      </div>

      {/* Side Navigation with Tooltips */}
      <div className="fixed left-6 top-1/2 -translate-y-1/2 z-20 space-y-4">
        <div className="relative group">
          <div className="w-12 h-12 bg-red-600/20 border border-red-500/30 rounded-xl backdrop-blur-sm flex items-center justify-center group-hover:bg-red-600/30 transition-all duration-300 cursor-pointer">
            <Flame className="w-6 h-6 text-red-400 group-hover:scale-110 transition-transform" />
          </div>
          {/* Tooltip */}
          <div className="absolute left-16 top-1/2 -translate-y-1/2 bg-black/90 text-white px-3 py-2 rounded-lg text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none whitespace-nowrap border border-red-500/30">
            UNDETECTED
            <div className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-1 w-2 h-2 bg-black/90 border-l border-b border-red-500/30 rotate-45"></div>
          </div>
        </div>

        <div className="relative group">
          <div className="w-12 h-12 bg-red-600/20 border border-red-500/30 rounded-xl backdrop-blur-sm flex items-center justify-center group-hover:bg-red-600/30 transition-all duration-300 cursor-pointer">
            <Target className="w-6 h-6 text-red-400 group-hover:scale-110 transition-transform" />
          </div>
          {/* Tooltip */}
          <div className="absolute left-16 top-1/2 -translate-y-1/2 bg-black/90 text-white px-3 py-2 rounded-lg text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none whitespace-nowrap border border-red-500/30">
            PREMIUM
            <div className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-1 w-2 h-2 bg-black/90 border-l border-b border-red-500/30 rotate-45"></div>
          </div>
        </div>

        <div className="relative group">
          <div className="w-12 h-12 bg-red-600/20 border border-red-500/30 rounded-xl backdrop-blur-sm flex items-center justify-center group-hover:bg-red-600/30 transition-all duration-300 cursor-pointer">
            <Rocket className="w-6 h-6 text-red-400 group-hover:scale-110 transition-transform" />
          </div>
          {/* Tooltip */}
          <div className="absolute left-16 top-1/2 -translate-y-1/2 bg-black/90 text-white px-3 py-2 rounded-lg text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none whitespace-nowrap border border-red-500/30">
            ULTRA FAST
            <div className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-1 w-2 h-2 bg-black/90 border-l border-b border-red-500/30 rotate-45"></div>
          </div>
        </div>
      </div>

      {/* Top Status Bar */}
      <div className="relative z-10 p-6">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-3">
              <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse" />
              <span className="text-red-400 font-mono text-sm">UNDETECTED</span>
            </div>
            <div className="h-4 w-px bg-red-500/30" />
            <div className="flex items-center gap-2 text-red-300 text-sm">
              <Zap className="w-4 h-4" />
              <span>PREMIUM</span>
            </div>
            <div className="h-4 w-px bg-red-500/30" />
            <div className="flex items-center gap-2 text-red-300 text-sm">
              <Rocket className="w-4 h-4" />
              <span>ULTRA FAST</span>
            </div>
          </div>

          <div className="flex items-center gap-4">
            {/* Discord Server Stats - Now showing online/offline */}
            <div className="px-4 py-2 bg-red-950/50 border border-red-500/30 rounded-lg backdrop-blur-sm">
              <div className="flex items-center gap-3 text-sm font-mono">
                {discordData.isLoading ? (
                  <div className="flex items-center gap-2 text-red-300">
                    <div className="w-4 h-4 border-2 border-red-500/30 border-t-red-500 rounded-full animate-spin" />
                    <span>Syncing...</span>
                  </div>
                ) : (
                  <>
                    <div className="flex items-center gap-2 text-green-400">
                      <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                      <span>{discordData.onlineCount}</span>
                      <span className="text-red-300">ONLINE</span>
                    </div>
                    <div className="w-px h-4 bg-red-500/30" />
                    <div className="flex items-center gap-2 text-gray-400">
                      <div className="w-2 h-2 bg-gray-500 rounded-full" />
                      <span>{discordData.offlineCount}</span>
                      <span className="text-red-300">OFFLINE</span>
                    </div>
                    <div className="w-px h-4 bg-red-500/30" />
                    <div className="flex items-center gap-2 text-red-300">
                      <Users className="w-4 h-4" />
                      <span>{discordData.memberCount}</span>
                      <span>TOTAL</span>
                    </div>
                  </>
                )}
              </div>
            </div>

            {/* Connection Status */}
            <div
              className={`w-10 h-10 rounded-lg backdrop-blur-sm flex items-center justify-center transition-all duration-300 ${
                discordData.source === "discord_api"
                  ? "bg-green-600/20 border border-green-500/30"
                  : "bg-orange-600/20 border border-orange-500/30"
              }`}
              title={statusIndicator.label}
            >
              <statusIndicator.icon className={`w-4 h-4 ${statusIndicator.color}`} />
            </div>

            {/* Refresh Button */}
            <button
              onClick={fetchDiscordData}
              disabled={discordData.isLoading}
              className="w-10 h-10 bg-red-600/20 border border-red-500/30 rounded-lg backdrop-blur-sm flex items-center justify-center hover:bg-red-600/30 transition-all duration-300 disabled:opacity-50"
              title="Refresh Discord Stats"
            >
              <RefreshCw className={`w-4 h-4 text-red-400 ${discordData.isLoading ? "animate-spin" : ""}`} />
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="relative z-10 flex items-center justify-center min-h-[calc(100vh-120px)] px-6">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Left Side - Content */}
            <div className="space-y-8">
              {/* Logo Badge */}
              <div className="inline-flex items-center gap-3 px-6 py-3 bg-red-950/30 border border-red-500/30 rounded-full backdrop-blur-sm">
                <div className="w-8 h-8 bg-gradient-to-br from-red-500 to-red-700 rounded-lg flex items-center justify-center">
                  <Star className="w-5 h-5 text-white fill-white" />
                </div>
                <span className="text-red-300 font-semibold">VayZ</span>
              </div>

              {/* Main Title */}
              <div className="space-y-4">
                <h1 className="text-6xl md:text-7xl font-black text-white leading-none">
                  DOMINATE
                  <br />
                  <span className="bg-gradient-to-r from-red-500 via-red-400 to-orange-400 bg-clip-text text-transparent">
                    THE GAME
                  </span>
                </h1>
                <div className="w-24 h-1 bg-gradient-to-r from-red-500 to-orange-400 rounded-full" />
              </div>

              {/* Description */}
              <p className="text-xl text-gray-300 leading-relaxed max-w-lg">
                Master the art of beaming with our cutting-edge tools and techniques. Designed for elite operators who
                demand precision and stealth in every operation.
              </p>

              {/* Stats */}
              <div className="flex gap-8">
                <div className="text-center">
                  <div className="text-3xl font-bold text-red-400">99.9%</div>
                  <div className="text-sm text-gray-400">Success Rate</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-red-400">24/7</div>
                  <div className="text-sm text-gray-400">Support</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-red-400">{discordData.memberCount}+</div>
                  <div className="text-sm text-gray-400">Community</div>
                </div>
              </div>

              {/* CTA Button - Now managed by admin panel */}
              <div className="pt-4">
                <div className="relative group inline-block">
                  <div className="absolute -inset-1 bg-gradient-to-r from-red-600 to-orange-600 rounded-2xl blur opacity-60 group-hover:opacity-100 transition duration-500" />
                  <Button
                    size="lg"
                    onClick={handleActivateClick}
                    className="relative px-10 py-6 text-lg font-bold bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 hover:to-red-600 text-white rounded-2xl transition-all duration-300 hover:scale-105 border-0 shadow-2xl"
                  >
                    <Flame className="w-5 h-5 mr-3" />
                    ACTIVATE NOW
                    <ExternalLink className="w-5 h-5 ml-3" />
                  </Button>
                </div>
              </div>
            </div>

            {/* Right Side - Feature Cards */}
            <div className="space-y-6">
              <div className="grid grid-cols-1 gap-4">
                {/* Feature Card 1 */}
                <div className="group p-6 bg-gradient-to-br from-red-950/40 to-red-900/20 border border-red-500/20 rounded-2xl backdrop-blur-sm hover:border-red-500/40 transition-all duration-300">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-red-600/20 rounded-xl flex items-center justify-center group-hover:bg-red-600/30 transition-colors">
                      <Zap className="w-6 h-6 text-red-400" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-white font-bold text-lg mb-2">Lightning Performance</h3>
                      <p className="text-gray-400 text-sm">
                        Experience unmatched speed and responsiveness with our optimized engine.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Feature Card 2 */}
                <div className="group p-6 bg-gradient-to-br from-red-950/40 to-red-900/20 border border-red-500/20 rounded-2xl backdrop-blur-sm hover:border-red-500/40 transition-all duration-300">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-red-600/20 rounded-xl flex items-center justify-center group-hover:bg-red-600/30 transition-colors">
                      <Shield className="w-6 h-6 text-red-400" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-white font-bold text-lg mb-2">Military-Grade Security</h3>
                      <p className="text-gray-400 text-sm">
                        Advanced protection protocols keep you safe and undetected at all times.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Feature Card 3 */}
                <div className="group p-6 bg-gradient-to-br from-red-950/40 to-red-900/20 border border-red-500/20 rounded-2xl backdrop-blur-sm hover:border-red-500/40 transition-all duration-300">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-red-600/20 rounded-xl flex items-center justify-center group-hover:bg-red-600/30 transition-colors">
                      <RefreshCw className="w-6 h-6 text-red-400" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-white font-bold text-lg mb-2">Auto-Evolution</h3>
                      <p className="text-gray-400 text-sm">
                        Continuous updates and improvements delivered seamlessly in real-time.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Status */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-10">
        <div className="flex items-center gap-4 px-6 py-3 bg-black/50 border border-red-500/30 rounded-full backdrop-blur-sm">
          <div className="flex items-center gap-2 text-sm text-red-300">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
            <span>Beamer Active</span>
          </div>
          <div className="w-1 h-1 bg-red-500 rounded-full" />
          <div className="flex items-center gap-2 text-sm text-red-300">
            <div
              className={`w-2 h-2 ${discordData.source === "discord_api" || discordData.source === "basic_guild_data" ? "bg-green-400" : "bg-red-400"} rounded-full animate-pulse`}
            />
            <span>
              {discordData.source === "discord_api" || discordData.source === "basic_guild_data"
                ? "Target Locked"
                : "Connection Lost"}
            </span>
          </div>
        </div>
      </div>
    </div>
  )
}
