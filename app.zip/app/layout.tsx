import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'VayZ',
  description: 'Master the art of beaming with our cutting-edge tools and techniques. Designed for elite operators who demand precision and stealth in every operation.',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
